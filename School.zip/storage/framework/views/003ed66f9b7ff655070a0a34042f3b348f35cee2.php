<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
      <div class="row justify-content-center">
        <div class="col-md-7">
          <div class="login-view">
        
          </div>
        </div>

        <div class="col-md-5">
          <div class="overlay2">
            <div class="overlay-1">
              <h2> Reset Password </h2>
            </div>
            <div class="overlay-3">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row" id="reset">
                            <div class="input-group">
                               <div class="input-group-prepend">
                                  <span class="input-group-text">
                                    <i class="fa fa-envelope"></i>
                                  </span>
                               </div>
                                <input id="email" type="email" class="col-lg-7 email form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="d-flex">
                          <button type="button" class="el-button--text float-left col-lg-4 mr-5">
                            <span><a href="/login" >Login</a></span>
                          </button>
                          <button id="password-reset " type="submit" class="btn btn-primary float-right">
                             <span> Send Password </span>
                          </button>
                            
                        </div>

                        
                       
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>