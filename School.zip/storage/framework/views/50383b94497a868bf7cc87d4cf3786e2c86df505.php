<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/addmodal.css')); ?>">
  <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
  <title>Document</title>
</head>
<body>
  <?php echo $__env->make('Pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isStudent')): ?>
        <div class="content">
          <div class="sidebar-content">
          </div>
          <div class="card" id="card-subjectgrade">
            <div class="card-body">
              <div class="title">
                <h1>List of Subjects</h1>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"> <ion-icon name="speedometer" id="dashboard-icon"> </ion-icon> <a href="/dashboard">Dashboard </a></li>
                    <li class="breadcrumb-item active" aria-current="page">List of Subject</li>
                  </ol>
                </nav>
              </div>
           
                <div class="table-wrapper-scroll-y">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Level</th>
                        <th>Subject Code</th>
                        <th>Subject Description</th>
                        <th>Remarks </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                      <td colspan="4" id="level"><strong>GRADE 1 </strong></td>
                      <?php $__currentLoopData = $grade1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade1s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td></td>
                          <td><?php echo e($grade1s->subjectCode); ?></td>
                          <td><?php echo e($grade1s->description); ?></td>
                          <td></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                      <tr>
                      <td colspan="4" id="level"><strong>GRADE 2 </strong></td>
                      <?php $__currentLoopData = $grade2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade2s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td></td>
                          <td><?php echo e($grade2s->subjectCode); ?></td>
                          <td><?php echo e($grade2s->description); ?></td>
                          <td></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr>
                    <td colspan="4" id="level"> <strong> GRADE 3 </strong></td>
                    <?php $__currentLoopData = $grade3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade3e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td></td>
                      <td><?php echo e($grade3e->subjectCode); ?></td>
                      <td><?php echo e($grade3e->description); ?></td>
                      <td></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <td colspan="4" id="level"><strong>GRADE 4 </strong></td>
                </tr>
                <tr>
                    <td colspan="4" id="level"><strong>GRADE 5 </strong></td>
                </tr>
                <tr>
                    <td colspan="4" id="level"><strong>GRADE 6 </strong></td>
                </tr>
                    </tbody>
                  </table>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  <script>

  
  </script>
</body>
</html>
<?php endif; ?>