<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
      <div class="row justify-content-center">
        <div class="col-md-7">
          <div class="login-view">
        
          </div>
        </div>

        <div class="col-md-5">
          <div class="overlay">
            <div class="overlay-1">
              <h1> Login </h1>
            </div>
            <div class="overlay-2">
              <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                    <div class="input-group input-group-md">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                              <i class="fa fa-envelope" aria-hidden="true"> </i>
                            </div>
                      </div>
                    <input id="email" type="email" class="col-sm-3 col-lg-8 form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> no-border" name="email" value="<?php echo e(old('email')); ?>" placeholder ="Email" >
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback ml-5" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  </div>

                  <div class="form-group">  
                    <div class="input-group input-group-md">
                      <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="fa fa-lock" aria-hidden="true"> </i>
                          </div>
                      </div>
                    <input id="password" type="password" class="col-sm-12 col-lg-8 form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> no-border" name="password" value="<?php echo e(old('password')); ?>"placeholder="Password" >
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback ml-5" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  </div>

                  
                
                  
                  <div class="d-flex">
                    <button type="button" class="el-button--text float-left col-lg-4 mr-2">
                        <span> <a href="<?php echo e(route('password.request')); ?>">Forgot password </a></span>
                      </button>
                      <button class="btn btn-default btn-login " type="submit" name="submit">
                          <?php echo e(__('Login')); ?>

                      </button>
                  </div>


                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>