<?php $__env->startSection('content'); ?>

      <?php echo $__env->make('Pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="content">
        <div class="sidebar-content">
        </div>
        
        <div class="row mt-4">
            <div class="col-lg-6">
                <div class="card" id="changepassword2">
                  <div class="card-body">
                      <form id="horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <h5 class="display-5">EDIT PROFILE </h5>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">First Name</Label>
                              <input  type="text" class="form-control col-lg-8" name="firstName" id="firstName" value="<?php echo e(Auth()->user()->firstName); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Last Name</Label>
                              <input  type="text" class="form-control col-lg-8" name="lastName" id="lastName" value="<?php echo e(Auth()->user()->lastName); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Middle Name</Label>
                              <input  type="text" class="form-control col-lg-8" name="middleName" id="middleName" value="<?php echo e(Auth()->user()->lastName); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Contact Number</Label>
                              <input  type="text" class="form-control col-lg-8" name="contactNumber" id="contactNumber" value="<?php echo e(Auth()->user()->contactNumber); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Address</Label>
                              <input  type="text" class="form-control col-lg-8" name="currentPassword" id="">
                            </div>
                        </div>
                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3"></Label>
                              <input  type="text" class="form-control col-lg-8" name="currentPassword" id="">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                            <div class="col-lg-3"> </div>
                            <button type="submit" class="btn btn-success col-lg-8" id="changepassButton">Edit</button>
                            </div>
                        </div>

                      </form>
                  </div>
                </div>
              </div>
              
          <div class="col-lg-6">
            <div class="card" id="changepassword">
              <div class="card-body">
                  <form action="" id="horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <h5 class="display-5">CHANGE PASSWORD</h5>
                    </div>
                    <div class="form-group" id="form-group">
                      <div class="row">
                        <Label class="col-lg-3">Current Password</Label>
                        <input  type="password" class="form-control col-lg-8" name="currentPassword" id="">
                      </div>
                    </div>

                    <div class="form-group" id="form-group">
                        <div class="row">
                          <Label class="col-lg-3">New Password</Label>
                          <input id="password" type="password" class="form-control col-lg-8" name="password" id="">
                        </div>
                    </div>

                    <div class="form-group" id="form-group">
                        <div class="row">
                          <Label class="col-lg-3">Confirm Password</Label>
                          <input id="password-confirm" type="password" class="form-control col-lg-8" name="password_confirmation " id="">
                        </div>
                    </div>

                    <div class="form-group" id="form-group">
                        <div class="row">
                        <div class="col-lg-3"> </div>
                        <button type="submit" class="btn btn-success col-lg-8" id="changepassButton">Reset</button>
                        </div>
                    </div>
                  </form>
              </div>
            </div>
          </div>
          
        </div>

      </div>
    </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>