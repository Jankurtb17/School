<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
      <div class="row justify-content-center">
        <div class="col-md-7">
          <div class="login-view">
        
          </div>
        </div>

        <div class="col-md-5">
          <div class="overlay">
            <div class="overlay-1">
              <h1> Teacher Login </h1>
            </div>
            <div class="overlay-2">
              <form method="POST" action="<?php echo e(route('teacher.login.submit')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> no-border" name="email" value="<?php echo e(old('email')); ?>" placeholder ="Email" >
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>

                  <div class="form-group">
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>"placeholder="Password" >
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>

                  <div class="form-group row">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    </div>
                    <div class="form-label">
                      <label class="form-check-label" for="remember">
                          <?php echo e(__('Remember Me')); ?>

                      </label>
                    </div>
                  </div>

                <div class="form-group">
                      <button type="submit" name="submit">
                          <?php echo e(__('Login')); ?>

                      </button>

                      <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                          <?php echo e(__('Forgot Your Password?')); ?>

                      </a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>