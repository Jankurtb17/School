<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('Pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTeacher')): ?>
        <div class="content">
          <div class="sidebar-content">
          </div>
          <div class="card" id="card-subjectgrade">
          <div class="card-body" >
          <div class="title">
            <h1>Subject Load</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"> <ion-icon name="speedometer" id="dashboard-icon"> </ion-icon> <a href="/dashboard">Dashboard </a></li>
                <li class="breadcrumb-item active" aria-current="page">Students</li>
              </ol>
            </nav>
            
           <div class="form-group">
              <?php if(session()->has('notif')): ?>
                <div class="alert alert-success" role="alert">
                    <button class="close" aria-hidden="true" data-dismiss="alert">&times; </button>
                    <i class="fa fa-check"  aria-hidden="true"></i> <strong>Grade</strong> <?php echo e(session()->get('notif')); ?>

                </div>
              <?php endif; ?>
           </div>

           <div class="form-group">
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger" role="alert">
                  <button class="close" aria-hidden="true" data-dismiss="alert">&times; </button>
                  <i class="fa fa-times" aria-hidden="true"></i>  <strong>Grade</strong> <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <?php if(count($errors)): ?>
              <div class="alert alert-danger" role="alert">
                  <button class="close" aria-hidden="true" data-dismiss="alert">&times; </button>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li> <?php echo e($error); ?> </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>
          </div>

            <div class="table-responsive mt-3">
              <table class="table table-hover" id="example">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>School Year</th>
                      <th>Grade Level</th>
                    </tr> 
                  </thead>

                  <tbody id="tbody">
                    <?php $__currentLoopData = $advisory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advisories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="post<?php echo e($advisories->id); ?>">
                          <td><?php echo e($advisories->id); ?></td>
                          <td><?php echo e($advisories->schoolYear); ?></td>
                          <td><a href="/studentgrades/<?php echo e($advisories->gradeLevel); ?>/<?php echo e($advisories->className); ?>"><?php echo e($advisories->gradeLevel); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>

         
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('scripts'); ?>
  <script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
      $(document).on('keyup', '#search', function() {
        
        value = $(this).val();
        $.ajax({
          url: "<?php echo e(route('search.subject')); ?>",
          type: "GET",
          data: {
            'search': value,
            '_token': $('input[name=_token]').val()
          },
          success:function(data) {
              $('tbody').html(data);
          }
        });
      })
  </script>
   <?php $__env->stopSection(); ?>
   <?php endif; ?>

<?php echo $__env->make('layouts.teacher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>