<?php $__env->startSection('content'); ?>
        <div class="content">
          <div class="sidebar-content">
          </div>
          <div class="row">
            <div class="col-lg-9">
              <div class="card" id="card-information1">
                <div class="card-body">
                  <div class="title">
                     <h3> Submitted Grades </h3>
                     <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"> <i class="fa fa-tachometer" aria-hidden = "true" id="dashboard-icon"> </i> <a href="/dashboard">Dashboard </a></li>
                            <li class="breadcrumb-item" aria-current="page"> <a href="/addteacher"> Students </a> </li>
                            <li class="breadcrumb-item active" aria-current="page">Teacher Information</li>
                        </ol>
                     </nav>
                  </div>
                  
                  
                  <form action="">
                    <div class="row">
                      <div class="col-lg-3">
                        <div class="form-group">
                          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <input type="hidden" id="employee_id" value="<?php echo e($users->employee_id); ?>" name="employee_id">
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <select name="schoolYear" id="schoolYear" class="form-control" required>
                            <option value="" selected disabled>-Select Advisory-</option>
                              <?php $__currentLoopData = $schoolyear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoolyears): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($schoolyears->schoolYear); ?>"><?php echo e($schoolyears->schoolYear); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>

                      <div class="col-lg-3">
                        <div class="form-group">
                          <select name="gradeLevel" id="gradeLevel" class="form-control dynamic" data-dependent="subjectCode" required>
                            <option value="" selected disabled>-Select Grade Level-</option>
                            <?php $__currentLoopData = $gradelevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gradeLevels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gradeLevels->gradeLevel); ?>"> <?php echo e($gradeLevels->gradeLevel); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>

                      <div class="col-lg-3">
                          <div class="form-group">
                            <select name="subjectCode" id="subjectCode" class="form-control" required>
                                <option value="" selected disabled>-Select Subject Code-</option>
                                <?php $__currentLoopData = $subjectCode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectCodes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subjectCodes->subjectCode); ?>"> <?php echo e($subjectCodes->subjectCode); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                      </div>

                      <div class="col-lg-3">
                        <button class="btn btn-success">Search</button>
                      </div>
                    </div>
                  </form>
                  <form action="<?php echo e(route('submitgrade.admin')); ?>" method="POST" id="form-submit">
                    <?php echo csrf_field(); ?>
                  <table class="table" id="example">
                      <thead>
                        <tr>
                         
                          <th>Student Id</th>
                          <th>Gender</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Grade</th>
                          <th>Remarks</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        
                      </tbody>
                  </table>
                    <button class="btn btn-dark" type="submit"> Submit Grade </button>
                  </form>
                </div>
              </div>
            </div>

            <div class="col-lg-3">
              <div class="card" id="card-information2">
                <div class="card-body">
                  <h4>Teacher Information </h4>
                  <div class="form-information">
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">  
                      <i class="fa fa-address-card-o mr-2" id="information-icon" aria-hidden="true"></i>
                         <span><?php echo e($users->employee_id); ?></span>
                     </div>
                     <div class="form-group">
                        <i class="fa fa-user-circle-o mr-2" id="information-icon" aria-hidden="true"></i>
                           <span><?php echo e($users->firstName); ?> <?php echo e($users->middleName); ?>. <?php echo e($users->lastName); ?></span>
                     </div>   
                     <div class="form-group">
                        <i class="fa fa-envelope mr-2" id="information-icon" aria-hidden="true"></i>
                           <span><?php echo e($users->email); ?></span>
                     </div>  
                     <div class="form-group">
                        <i class="fa fa-phone-square mr-2" id="information-icon" aria-hidden="true"></i>
                           <span><?php echo e($users->phone_number); ?></span>
                     </div>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
  $('.btn-dark').hide();
});
$(document).on('submit', 'form', function(e) {
    e.preventDefault();
    $.ajax({
        url: '<?php echo e(route("searchgrade.admin")); ?>',
        method: 'POST',
        data: {
          "_token": $('input[name=_token]').val(),
          "gradeLevel": $('#gradeLevel').val(),
          "subjectCode": $('#subjectCode').val(),
          "schoolYear": $('#schoolYear').val(),
          "employee_id": $('#employee_id').val()
        },
        success:function(data) {
          $('tbody').html(data);
          $('.btn-dark').show();
        }
    });
});

$(document).on('submit', '#form-submit', function() {
    $.ajax({
        url: "<?php echo e(route('submitgrade.admin')); ?>",
        method: "POST",
        data: {
          "student_id": $('#student_id').val(),
          "grade": $('#grade').val(),
          "_token": $('input[name=_token]').val()
        },
        success:function(data)
        {

        }
    });
}); 

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>