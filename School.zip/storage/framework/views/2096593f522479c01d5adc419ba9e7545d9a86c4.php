<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
        <title><?php echo e(config('app.name', 'School')); ?></title>
    </head>
    <body>
        <div class="container">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
