<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('Pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content">
          <div class="sidebar-content">
          </div>
          <div class="card" id="card-subjectgrade">
            <div class="card-body">
              <div class="title">
                <h1>GRADE ENCODING</h1>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"> <ion-icon name="speedometer" id="dashboard-icon"> </ion-icon> <a href="/dashboard">Dashboard </a></li>
                      <li class="breadcrumb-item active" aria-current="page">GRADE ENCODING</li>
                    </ol>
                  </nav>

                <?php if(count($errors)): ?>
                  <div class="alert alert-danger" role="alert">
                      <button class="close" data-dismiss="alert" aria-hidden="true">&times; </button>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li> <?php echo e($error); ?> </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>

                <form method="POST" id="form-submit" action="<?php echo e(route('studentgrades.grade')); ?>"> 
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-lg-3">
                    <div class="form-group">
                      <select name="subjectCode" id="subjectCode" class="form-control" required>
                        <option value="" selected disabled>-Select Subject-</option>
                        <?php $__currentLoopData = $advisory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advisories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($advisories->subjectCode); ?>"><?php echo e($advisories->subjectCode); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-lg-2">
                      <div class="form-group">
                        <select name="gradingperiod" class="form-control" required>
                          <option value="" selected disabled>-Select Grading Period-</option>
                          <option value="1">1st</option>
                          <option value="2">2nd</option>
                          <option value="3">3rd</option>
                          <option value="4">4th</option>
                        </select>
                      </div>
                    </div>
                    <?php $__currentLoopData = $advisory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advisories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="schoolYear" value="<?php echo e($advisories->schoolYear); ?>">
                    </td><input type="hidden" name="className" value="<?php echo e($advisories->className); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="table-wrapper-scroll-y">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>ID Number</th>
                      <th>Gender</th>
                      <th>Student Name</th>
                      <th>Input Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><input type="hidden" name="student_id[]" value="<?php echo e($users->student_id); ?>"><?php echo e($users->student_id); ?></td>
                          <td><?php echo e($users->gender); ?></td>
                          <td><?php echo e($users->firstName); ?> <?php echo e($users->middleName); ?> <?php echo e($users->lastName); ?></td>
                          <td><input  type="text" name="grade[]" class="form-control col-lg-2" id="grade" onkeypress="isNumber(event)" maxlength="5" required></td>
                          <input type="hidden" name="gradeLevel[]" value="<?php echo e($users->gradeLevel); ?>">
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                </div>
                <button type="submit" class="btn btn-success">Submit Grade </button>
                </form>
              </div>       
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
  </div>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>
  <script>
     function isNumber(evt) {
      var ch = String.fromCharCode(evt.which);
      if(!/^[0-9.\b]+$/.test(ch)) {
        evt.preventDefault();
      }
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>