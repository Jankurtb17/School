<?php $__env->startSection('content'); ?>

      <?php echo $__env->make('Pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="content">
        <div class="sidebar-content">
        </div>
        
        <div class="row mt-4">
            <div class="col-lg-6">
                <div class="card" id="changepassword2">
                  <div class="card-body">
                      <form id="horizontal" action="">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <h5 class="display-5">EDIT PROFILE </h5>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">First Name</Label>
                              <input  type="text" class="form-control col-lg-8" name="firstName" id="firstName" value="<?php echo e(Auth()->user()->firstName); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Last Name</Label>
                              <input  type="text" class="form-control col-lg-8" name="lastName" id="lastName" value="<?php echo e(Auth()->user()->lastName); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Middle Name</Label>
                              <input  type="text" class="form-control col-lg-8" name="middleName" id="middleName" value="<?php echo e(Auth()->user()->middleName); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Contact Number</Label>
                              <input  type="text" class="form-control col-lg-8" name="contactNumber" id="contactNumber" value="<?php echo e(Auth()->user()->phone_number); ?>">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3">Address</Label>
                            <input  type="text" class="form-control col-lg-8" name="currentPassword" id="Address">
                            </div>
                        </div>
                        <div class="form-group" id="form-group">
                            <div class="row">
                              <Label class="col-lg-3"></Label>
                              <input  type="text" class="form-control col-lg-8" name="currentPassword" id="Address1">
                            </div>
                        </div>

                        <div class="form-group" id="form-group">
                            <div class="row">
                            <div class="col-lg-3"> </div>
                            <button type="submit" class="btn btn-primary col-lg-8" id="changepassButton">Edit</button>
                            </div>
                        </div>

                      </form>
                  </div>
                </div>
              </div>
              
          <div class="col-lg-6">
            <div class="card" id="changepassword">
              <div class="card-body">

              
                  <form class="form-horizontal" method="POST"action="<?php echo e(route('changePassword')); ?>" id="horizontal">
                    <?php echo csrf_field(); ?>
                  
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success changepass-alert">
                        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&times; </button>
                        <strong> Password </strong> <?php echo e(session()->get('success')); ?>

                    </div>
                  <?php endif; ?>
  
                  <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger changepass-alert">
                        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&times; </button>
                        <strong> Password </strong> <?php echo e(session()->get('error')); ?>

                    </div>
                  <?php endif; ?>
                  <div class="form-group">
                      <h5 class="display-5">CHANGE PASSWORD</h5>
                  </div>
                    <div class="form-group<?php echo e($errors->has('current-password') ? 'has-error' : ''); ?>" id="form-group">
                      <div class="row">
                        <Label class="col-lg-3 control-label">Current Password</Label>
                        <input  type="password" class="form-control col-lg-8" name="current-password">
                        <?php if($errors->has('current-password')): ?>
                          <span class="help-block">
                            <strong><?php echo e($errors->first('current-password')); ?></strong>
                          </span>
                        <?php endif; ?>
                      </div>
                    </div>

                    <div class="form-group" id="form-group">
                        <div class="row">
                          <Label class="col-lg-3">New Password</Label>
                          <input id="password" type="password" class="form-control col-lg-8" name="new-password">
                          <?php if($errors->has('new-password')): ?>
                            <span class="help-block">
                              <strong><?php echo e($errors->first('new-password')); ?></strong>
                            </span>
                          <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group" id="form-group">
                        <div class="row">
                          <Label class="col-lg-3">Confirm Password</Label>
                          <input id="password-confirm" type="password" class="form-control col-lg-8" name="new-password_confirmation">
                        </div>
                    </div>

                    <div class="form-group" id="form-group">
                        <div class="row">
                        <div class="col-lg-3"> </div>
                        <button type="submit" class="btn btn-primary col-lg-8" id="changepassButton2">Change Password</button>
                        </div>
                    </div>
                  </form>
              </div>
            </div>
          </div>
          
        </div>

      </div>
    </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>