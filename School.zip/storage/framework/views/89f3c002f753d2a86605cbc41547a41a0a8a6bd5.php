<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="row">
    <div class="col-md-7 col-sm-7 col-xs-12">
      <div class="login-view">

      </div>
    </div>

    <div class="col-md-5 col-sm-5 col-xs-12">
      <div class="overlay">
        <div class="overlay-1">
          <h1>Login </h1>
        </div>

        <?php if(isset(Auth::user()->email)): ?>
          <script>window.location='/dashboard';</script>
        <?php endif; ?>

        <?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="close">&times; 
            <strong><?php echo e($message); ?></strong>
            </button>
          </div>
        <?php endif; ?>

        <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>

        <div class="overlay-2">
        <form method="POST" action="<?php echo e(url('/checkLogin')); ?>">
          <?php echo csrf_field(); ?>
            <div class="form-group">
              <input type="text"  placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <a href="#">Forgot Password? </a>
              </div>
            <div class="form-group">
              <button type="submit" name="submit"> Login </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Login.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>