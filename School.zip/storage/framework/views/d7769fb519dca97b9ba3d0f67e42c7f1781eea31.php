<div class="app-body">
    <div class="sidebar">
      <div class="sidebar-content">
          <nav class="sidebar-nav">
            <ul class="nav" id="menulist">
              <div class="main-content">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <div class="sidebar-image">
                    <img src="<?php echo e(url('image/admin.png')); ?>" class="logo-admin">
                </div>

                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTeacher')): ?>
                <div class="sidebar-image">
                    <img src="<?php echo e(url('image/teacher.png')); ?>" class="logo-admin">
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isStudent')): ?>
                <div class="sidebar-image">
                    <img src="<?php echo e(url('image/student.png')); ?>" class="logo-admin">
                </div>
                <?php endif; ?>
              </div>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
              <li class="nav-title"> Main Module </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(setActive('dashboard', 'current')); ?>" href="/dashboard"> <i class="fa fa-tachometer" aria-hidden="true" id="icon-dashboard"></i> Dashboard </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(setActive('schoolyear', 'current')); ?>" href="/schoolyear"> <i class="fa fa-calendar" aria-hidden="true" id="icon-dashboard"></i> School Year</a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('gradelevel', 'current')); ?>" href="/gradelevel"> <i class="fa fa-calendar" aria-hidden="true" id="icon-dashboard"></i> Grade Level</a>
             </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(setActive('examination', 'current')); ?>" href="/examination"> <i class="fa fa-calendar" aria-hidden="true" id="icon-dashboard"></i> Examination Date</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(setActive('student', 'current')); ?>" href="/student"> <i class="fa fa-user" aria-hidden="true" id="icon-dashboard"></i> Students  <span class="badge badge-success ml-3"><?php echo e($student); ?></span> </a>
              </li>
            
              
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('addteacher', 'current')); ?>" href="/addteacher"> <i class="fa fa-user" aria-hidden="true" id="icon-dashboard"></i> Teachers <span class="badge badge-success ml-3"><?php echo e($teacher); ?></span> </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(setActive('advisory', 'current')); ?>" href="/advisory"> <i class="fa fa-user" aria-hidden="true" id="icon-dashboard"></i> Teachers Advisory </a>
              </li>
              
              <li class="nav-title"> Settings </li>
              <li class="nav-item">
                <a class="nav-link" href="/settings"> <i class="fa fa-cog" aria-hidden="true" id="icon-dashboard"></i> Account Settings </a>
              </li>
              <?php endif; ?>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTeacher')): ?>
              <li class="nav-title"> Main Navigation </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('subjectload', 'current' )); ?>" href="/subjectload"> <i class="fa fa-book" aria-hidden="true" id="icon-dashboard"> </i> Subject Module </a>
                <ul>
                  <li class="nav-item"> <a class="nav-link" href="#">Example</a></li>
                </ul>
              </li>
             
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('viewgrades', 'current' )); ?>" href="/viewgrades"> <i class="fa fa-book" aria-hidden="true" id="icon-dashboard"> </i> View Student Grades </a>
              </li>
              
              <li class="nav-title"> Settings </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('settings', 'current')); ?>" href="/settings"> <i class="fa fa-cog" aria-hidden="true" id="icon-dashboard"></i> Account Settings </a>
              </li>
              <?php endif; ?>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isStudent')): ?>
              <li class="nav-title"> Main Navigation </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('listsubject', 'current' )); ?>" href="/listsubject"> <i class="fa fa-book" aria-hidden="true" id="icon-dashboard"> </i> List of subject </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('grades', 'current' )); ?>" href="/grades"> <i class="fa fa-book" aria-hidden="true" id="icon-dashboard"> </i> Grades </a>
              </li>
              <li class="nav-title"> Settings </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('settings', 'current' )); ?>" href="/settings"> <i class="fa fa-cog" aria-hidden="true" id="icon-dashboard"></i> Account Settings </a>
              </li>
              <?php endif; ?>
            </ul>
          </nav>
      </div>
    </div>

<div class="main">
  <div class="navbar-top">
    <ul class="navbar-nav">
      <?php if(isset(Auth::user()->firstName)): ?>
        <li class="navbar-na">
          <a class="navbar-naa" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">
            <?php echo e(Auth::user()->firstName); ?>    <i class="fa fa-caret-down" aria-hidden="true"></i>
          </a> 
          <div class="dropdown-menu" id="dropdown">
           
          <a class="dropdown-item"  href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
              <i class="fa fa-sign-out" aria-hidden="true"></i> <?php echo e(__('Logout')); ?>

            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
            </form>
          </div>
        </li>
      <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(asset('login')); ?>"> <?php echo e(__('Login')); ?> </a>
          </li>
      <?php endif; ?>
    </ul>
</div>