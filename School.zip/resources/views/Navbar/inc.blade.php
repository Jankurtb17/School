<nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
    <a href="javascript(void:0)" class="navbar-brand"> School </a>
    
</nav>